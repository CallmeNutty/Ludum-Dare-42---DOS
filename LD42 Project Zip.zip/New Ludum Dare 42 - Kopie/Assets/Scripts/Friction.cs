﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Friction : MonoBehaviour
{
    [Tooltip("Putting this below 1 will apply negative friction")]
    public float groundFriction;
    [Tooltip("Putting this below 1 will apply negative friction")]
    public float airFriction;

    private Rigidbody2D rb2d;

	// Use this for initialization
	void Start ()
    {
        rb2d = gameObject.GetComponent<Rigidbody2D>();
    }
	
	// Update is called once per frame
	void FixedUpdate ()
    {
        //Friction
        if (rb2d.velocity.x > 0 || rb2d.velocity.x < 0)
        {
            rb2d.velocity = new Vector2(rb2d.velocity.x / groundFriction, rb2d.velocity.y / airFriction);
        }
    }
}
