﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewTrash : MonoBehaviour
{
    public GameObject newRecyclingBin;

    private GameObject[] allPointers;

    void OnTriggerEnter2D(Collider2D coll)
    {
        if (coll.gameObject.tag == "Player")
        {
            foreach (GameObject k in allPointers)
            {
                k.GetComponent<Deleter>().currentRecyclingBin = newRecyclingBin;
            }
        }
    }

    // Use this for initialization
    void Start ()
    {
        allPointers = GameObject.FindGameObjectsWithTag("Pointer");
    }
	
	// Update is called once per frame
	void Update ()
    {
		
	}
}
