﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Escape : MonoBehaviour
{
	// Update is called once per frame
	void Update ()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            //If already on home screen
            if(SceneManager.GetActiveScene().buildIndex == 0)
            {
                //Close hame
                Application.Quit();
            }
            else
            {
                //Go to homescreen
                SceneManager.LoadScene(0);
            }
        }
	}
}
