﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Button : MonoBehaviour
{
    private bool objectOn;

    public GameObject gate;
    private SpriteRenderer gateRenderer;
    private BoxCollider2D gateBox;

    public Vector2 playerTarget;
    public AudioSource bossButtonAudioSource;

    public enum Purpose { OpenGate, BossButton }
    public Purpose purpose;

    void OnTriggerStay2D(Collider2D coll)
    {
        objectOn = true;
    }

    void OnTriggerExit2D(Collider2D coll)
    {
        objectOn = false;
    }

    void Start()
    {
        if(gate != null)
        {
            gateRenderer = gate.GetComponent<SpriteRenderer>();
            gateBox = gate.GetComponent<BoxCollider2D>();
        }
    }

    void Update()
    {
        if(objectOn == true)
        {
            //Iterate through all possible commands
            switch (purpose)
            {
                case Purpose.OpenGate:
                    Hide();
                    break;
                case Purpose.BossButton:
                    GameObject.FindGameObjectWithTag("Player").GetComponent<Movement>().Flip(playerTarget);
                    bossButtonAudioSource.Play();
                    Destroy(gameObject);
                    break;
            }
        }
        else
        {
            switch (purpose)
            {
                case Purpose.OpenGate:
                    Show();
                    break;
                case Purpose.BossButton:
                    break;
            }
        }
    }

    void Hide()
    {
        gateRenderer.color = new Color(gateRenderer.color.r, gateRenderer.color.g, gateRenderer.color.b, 0.5f);
        gateBox.enabled = false;
    }

    void Show()
    {
        gateRenderer.color = new Color(gateRenderer.color.r, gateRenderer.color.g, gateRenderer.color.b, 1);
        gateBox.enabled = true;
    }
}
