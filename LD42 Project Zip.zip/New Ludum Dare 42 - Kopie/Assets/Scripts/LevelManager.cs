﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class LevelManager : MonoBehaviour
{
    public Text levelText;
    public Text deathsText;

    public GameObject errorMessage;
    private AudioSource audioSource;
    public AudioClip errorSound;

    public GameObject winMessage;

    public delegate void GameEvent();
    public GameEvent gameOver;
    public GameEvent gameWin;

    public GameObject gameManager;
    private GameObject inGameManager;

	// Use this for initialization
	void Start ()
    {
        inGameManager = GameObject.FindGameObjectWithTag("GameController");

        if(inGameManager == null)
        {
            Instantiate(gameManager);
            inGameManager = GameObject.FindGameObjectWithTag("GameController");
        }
        else if (inGameManager.GetComponent<AudioSource>().isPlaying != true)
        {
            Destroy(inGameManager);

            Instantiate(gameManager);
            inGameManager = GameObject.FindGameObjectWithTag("GameController");
        }

        audioSource = gameObject.GetComponent<AudioSource>();

        levelText.text = "Level: " + (SceneManager.GetActiveScene().buildIndex);
        deathsText.text = "Deaths: " + GlobalStats.deaths;

        gameWin = GameWin;
        gameOver = GameEnd;


        Time.timeScale = 0;
	}
	
	// Update is called once per frame
	void Update ()
    {
        if (Input.GetKeyDown(KeyCode.LeftArrow) || Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.X))
        {
            Time.timeScale = 1;
        }

        if (Input.GetKeyDown(KeyCode.Space))
        {
            GlobalStats.deaths += 1;
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex, LoadSceneMode.Single);
        }
    }

    void GameEnd()
    {
        //Display and play error
        errorMessage.SetActive(true);
        audioSource.clip = errorSound;
        audioSource.Play();

        //Stop Music
        GameObject.FindGameObjectWithTag("GameController").GetComponent<AudioSource>().Stop();

        GlobalStats.deaths += 1;

        Time.timeScale = 0;
    }

    void GameWin()
    {
        //Display and play error
        winMessage.SetActive(true);

        Time.timeScale = 0;
    }
}
