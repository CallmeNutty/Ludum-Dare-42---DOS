﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OutsideCameraDeath : MonoBehaviour
{
    private bool gameOver;

    private GameObject player;
    private Vector3 camView;

	// Use this for initialization
	void Start ()
    {
        player = GameObject.FindGameObjectWithTag("Player");
	}
	
	// Update is called once per frame
	void Update ()
    {
        if(player != null) { camView = Camera.main.WorldToViewportPoint(player.transform.position); }

        //If player is outside the camera's view
        if ((camView.x < 0 || camView.x > 1 || camView.y < 0 || camView.y > 1) && gameOver == false)
        {
            GameObject.FindGameObjectWithTag("LevelManager").GetComponent<LevelManager>().gameOver();
            gameOver = true;
        }
	}
}
