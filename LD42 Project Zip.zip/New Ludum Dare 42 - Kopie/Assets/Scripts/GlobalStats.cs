﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GlobalStats : MonoBehaviour
{
    public static int deaths = 0;

    void Start()
    {
        DontDestroyOnLoad(gameObject);
    }
}
