﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraNewArea : MonoBehaviour
{
    public float time;
    public Vector3 position;

    void Start()
    {
        position = transform.position;
    }

    // Update is called once per frame
    void Update ()
    {
        transform.position = Vector3.Lerp(transform.position, position, time * Time.deltaTime);
	}
}
