﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Freezer : MonoBehaviour
{
    public float length;
    //All deleter scripts on every pointer
    private Deleter[] deleter;

    void OnTriggerEnter2D(Collider2D coll)
    {
        foreach (Deleter k in deleter)
        {
            k.frozen = true;
        }
    }

    void OnTriggerExit2D(Collider2D coll)
    {
        foreach (Deleter k in deleter)
        {
            k.frozen = false;
        }
    }

    // Use this for initialization
    void Start ()
    {
        //Fill deleter[] with every pointer
        GetPointers();
	}

    void GetPointers()
    {
        //Store reference to every pointer GameObject
        GameObject[] allPointers = GameObject.FindGameObjectsWithTag("Pointer");

        deleter = new Deleter[allPointers.Length];

        for (int k = 0; k < allPointers.Length; k++)
        {
            deleter[k] = allPointers[k].GetComponent<Deleter>();
        }
    }
}
