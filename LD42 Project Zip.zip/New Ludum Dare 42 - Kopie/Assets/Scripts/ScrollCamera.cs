﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScrollCamera : MonoBehaviour
{
    public Vector2 scrollSpeed;

    // Update is called once per frame
    void Update()
    {
        transform.position = new Vector3(transform.position.x + scrollSpeed.x * Time.deltaTime, transform.position.y + scrollSpeed.y * Time.deltaTime, -10);
	}
}
