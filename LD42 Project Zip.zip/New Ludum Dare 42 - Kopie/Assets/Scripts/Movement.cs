﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    public float horizontalForce;
    public float maxHorizontal;
    
    private int jumpCount;
    public int maxJumps;

    public float jumpForce;
    public float maxVertical;
    public ParticleSystem jumpParticles;

    public float rayDistance;
    public LayerMask layersToCheck;

    private Rigidbody2D rb2d;

    private Animator animator;

    public AudioSource audioSource;
    public AudioClip jump;
    public AudioClip land;

    //MoveTo set co-ordinate
    public Vector3 targetLocation;
    public bool lockMovement;

    void OnCollisionEnter2D(Collision2D coll)
    {
        if ((coll.gameObject.tag == "Block" || coll.gameObject.tag == "Pointer") && rb2d.velocity.y <= 0)
        {
            Land();
        }
    }

    void OnCollisionStay2D(Collision2D coll)
    {
        if ((coll.gameObject.tag == "Block" || coll.gameObject.tag == "Pointer") && rb2d.velocity.y == 0)
        {
            //Re-enable jumping
            jumpCount = maxJumps;
        }
    }

    void OnTriggerEnter2D(Collider2D coll)
    {
        if (coll.gameObject.tag == "Pointer" && rb2d.velocity.y <= 0)
        {
            //Re-enable jumping
            jumpCount = maxJumps;
        }
    }

    // Use this for initialization
    void Start ()
    {
        jumpCount = maxJumps;

        rb2d = gameObject.GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
	}
	
	// Update is called once per frame
	void Update ()
    {
        if (Input.GetKey(KeyCode.LeftArrow) && animator.GetBool("Flipping") == false)
        {
            rb2d.AddForce(new Vector2(-horizontalForce * Time.deltaTime, 0), ForceMode2D.Impulse);
        }
        if (Input.GetKey(KeyCode.RightArrow) && animator.GetBool("Flipping") == false)
        {
            rb2d.AddForce(new Vector2(horizontalForce * Time.deltaTime, 0), ForceMode2D.Impulse);
        }

        if ((Input.GetKeyDown(KeyCode.X) && jumpCount > 0) && animator.GetBool("Flipping") == false)
        {
            Jump();
        }

        //If reached target location and still locked
        if (lockMovement == true && transform.position == targetLocation && animator.GetBool("Flipping") == true)
        {
            //Allow movement
            lockMovement = false;
            //Stop flipping animation
            animator.SetBool("Flipping", false);
            //Re-activate collider
            gameObject.GetComponent<CapsuleCollider2D>().enabled = true;
            //Reset Rigibody
            rb2d.bodyType = RigidbodyType2D.Dynamic;
        }
        else if (lockMovement == true)
        {
            //Continue moving to point
            transform.position = Vector2.MoveTowards(transform.position, targetLocation, 10 * Time.deltaTime);
        }
    }

    void FixedUpdate()
    {
        Debug.DrawRay(transform.position, new Vector3(0, -rayDistance), Color.green, 0);

        LimitHorizontal(maxHorizontal);
        LimitVertical(maxVertical);
    }

    void Jump()
    {
        audioSource.clip = jump;
        audioSource.Play();

        rb2d.velocity = new Vector2(rb2d.velocity.x, 0);
        rb2d.AddForce(new Vector2(0, jumpForce));

        jumpCount -= 1;
    }

    void Land()
    {
        audioSource.clip = land;
        audioSource.Play();

        jumpParticles.Play();
    }

    public void Flip(Vector2 location)
    {
        lockMovement = true;

        rb2d.velocity = new Vector2(0, 0);
        rb2d.bodyType = RigidbodyType2D.Static;
        targetLocation = location;
        animator.SetBool("Flipping", true);
    }

    void LimitHorizontal(float maxSpeed)
    {
        Vector3 v = rb2d.velocity;
        v.x = Mathf.Clamp(v.x, -maxSpeed, maxSpeed);
        rb2d.velocity = v;
    }

    void LimitVertical(float maxSpeed)
    {
        Vector3 v = rb2d.velocity;
        v.y = Mathf.Clamp(v.y, -maxSpeed, maxSpeed);
        rb2d.velocity = v;
    }
}
