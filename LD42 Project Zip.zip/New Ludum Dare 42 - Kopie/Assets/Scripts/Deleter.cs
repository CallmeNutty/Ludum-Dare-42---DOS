﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Deleter : MonoBehaviour
{
    public float speed;
    [HideInInspector]
    public float defaultSpeed;
    public bool frozen;

    public List<GameObject> objectsToDelete;
    
    public GameObject currentRecyclingBin;
    private LevelManager levelManager;

    private Movement playerMovement;

    public AudioSource audioSource;
    public AudioClip click;
    public AudioClip release;

    void OnTriggerEnter2D(Collider2D coll)
    {
        if (objectsToDelete.Count > 0)
        {
            if (coll.gameObject == objectsToDelete[0])
            {
                PickUp();
            }
        }
    }

    // Use this for initialization
    void Start()
    {
        levelManager = GameObject.FindGameObjectWithTag("LevelManager").GetComponent<LevelManager>();
        objectsToDelete[0].GetComponent<SpriteRenderer>().color = Color.red;
        playerMovement = GameObject.FindGameObjectWithTag("Player").GetComponent<Movement>();

        if (objectsToDelete.Count > 1)
        {
            objectsToDelete[1].GetComponent<SpriteRenderer>().color = Color.yellow;
        }

        defaultSpeed = speed;
    }

    // Update is called once per frame
    void Update()
    {
        if (playerMovement.lockMovement == true || frozen == true){ speed = 0; }
        else if (playerMovement.lockMovement == false && frozen == false ) { speed = defaultSpeed; }

        //If not moving object and objects still to delete
        if (transform.childCount == 0 && objectsToDelete.Count > 0)
        {
            transform.position = Vector2.MoveTowards(transform.position, objectsToDelete[0].transform.position, speed * Time.deltaTime);
        }

        if (objectsToDelete.Count == 0)
        {
            levelManager.gameOver();
            Destroy(gameObject);

            return;
        }

        //If reached recycling bin
        if (transform.position == currentRecyclingBin.transform.position && objectsToDelete.Count > 0)
        {
            Release();
        }

        //If carrying object
        if (transform.childCount > 0)
        {
            transform.position = Vector2.MoveTowards(transform.position, currentRecyclingBin.transform.position, speed * Time.deltaTime);
        }
    }

    void PickUp()
    {
        objectsToDelete[0].transform.parent = transform;

        //Disable necessary components
        if (objectsToDelete[0].GetComponent<Movement>() != null) { objectsToDelete[0].GetComponent<Movement>().enabled = false; }
        if (objectsToDelete[0].GetComponent<BoxCollider2D>() != null) { objectsToDelete[0].GetComponent<BoxCollider2D>().enabled = false; }
        if (objectsToDelete[0].GetComponent<CapsuleCollider2D>() != null) { Destroy(objectsToDelete[0].GetComponent<CapsuleCollider2D>()); }
        if (objectsToDelete[0].GetComponent<Rigidbody2D>() != null) { objectsToDelete[0].GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Static; }

        audioSource.clip = click;
        audioSource.Play();
    }

    void Release()
    {
        objectsToDelete.RemoveAt(0);
        Destroy(transform.GetChild(0).gameObject);

        if (objectsToDelete.Count > 0)
        {
            //Mark next object red
            objectsToDelete[0].GetComponent<SpriteRenderer>().color = Color.red;
        }

        if (objectsToDelete.Count > 1)
        {
            //Mark next next object yellow
            objectsToDelete[1].GetComponent<SpriteRenderer>().color = Color.yellow;
        }

        audioSource.clip = release;
        audioSource.Play();
    }
}
